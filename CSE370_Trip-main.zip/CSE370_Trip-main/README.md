Travel App Prototype
